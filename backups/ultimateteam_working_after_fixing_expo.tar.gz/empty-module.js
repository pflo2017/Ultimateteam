// This is an empty module used as a stub for Node.js core modules
// that are not available or needed in the React Native environment. 