-- Completely disable RLS for testing
ALTER TABLE activity_presence DISABLE ROW LEVEL SECURITY;
