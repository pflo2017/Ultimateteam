#!/bin/bash

# Apply the new migration
npx supabase migrations up

echo "Migration applied successfully!" 