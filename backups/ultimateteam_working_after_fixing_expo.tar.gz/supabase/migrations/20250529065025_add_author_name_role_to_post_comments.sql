ALTER TABLE post_comments ADD COLUMN IF NOT EXISTS author_name TEXT; ALTER TABLE post_comments ADD COLUMN IF NOT EXISTS author_role TEXT;
